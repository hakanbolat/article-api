# Iterable

- `v::iterable()`

**Deprecated**: Use [IterableType](IterableType.md) instead.
See also:

  * [IterableType](IterableType.md)
