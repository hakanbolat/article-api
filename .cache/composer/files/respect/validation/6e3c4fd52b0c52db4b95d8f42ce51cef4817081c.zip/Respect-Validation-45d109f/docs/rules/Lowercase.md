# Lowercase

- `v::lowercase()`

Validates if string characters are lowercase in the input:

```php
v::stringType()->lowercase()->validate('xkcd'); // true
```

***
See also:

  * [Uppercase](Uppercase.md)
