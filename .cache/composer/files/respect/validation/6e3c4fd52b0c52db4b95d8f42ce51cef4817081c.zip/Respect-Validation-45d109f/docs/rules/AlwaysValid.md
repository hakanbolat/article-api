# AlwaysValid

- `v::alwaysValid()`

Always returns true.

```php
v::alwaysValid()->validate($whatever); // true
```

***
See also:

  * [AlwaysInvalid](AlwaysInvalid.md)
