# AlwaysInvalid

- `v::alwaysInvalid()`

Always return false.

```php
v::alwaysInvalid()->validate($whatever); // false
```

***
See also:

  * [AlwaysValid](AlwaysValid.md)
  * [When](When.md)
