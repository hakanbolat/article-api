# Alpha

- `v::alpha()`
- `v::alpha(string $additionalChars)`

This is similar to `v::alnum()`, but it doesn't allow numbers.

***
See also:

  * [Alnum](Alnum.md)
  * [Charset](Charset.md)
  * [Consonant](Consonant.md)
  * [Digit](Digit.md)
  * [NoWhitespace](NoWhitespace.md)
  * [Regex](Regex.md)
  * [Vowel](Vowel.md)
