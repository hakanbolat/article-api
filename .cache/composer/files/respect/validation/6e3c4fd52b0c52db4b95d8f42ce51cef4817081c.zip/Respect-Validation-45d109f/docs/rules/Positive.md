# Positive

- `v::positive()`

Validates if a number is higher than zero

```php
v::numeric()->positive()->validate(-15); // false
```

***
See also:

  * [Negative](Negative.md)
