# Changelog

The changelog is moved to the [releases page](https://github.com/zircote/swagger-php/releases)
