<?php declare(strict_types=1);

namespace OpenApi\Tests\Fixtures;

use OpenApi\Annotations as OA;

/**
 * @SWG\Definition()
 */
class Deprecated
{
}
