<?php

namespace AnotherNamespace\Annotations;

/**
 * @Annotation
 */
class Constants
{
    const INVALID_TIMEZONE_LOCATION = "invalidTimezoneLocation";
}