# Supported Annotations

Currently there is no manually documented list of annotations. Still you can figure out what annotations are supported:

- You can look at the [`OpenApi\Annotations` namespace in the source code](https://github.com/zircote/swagger-php/tree/master/src/Annotations).
- There also are a couple of [examples](https://github.com/zircote/swagger-php/tree/master/Examples) which might help you out.
