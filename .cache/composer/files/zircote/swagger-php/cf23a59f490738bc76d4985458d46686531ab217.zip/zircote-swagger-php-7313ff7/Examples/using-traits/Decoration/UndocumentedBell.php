<?php

namespace UsingTraits\Decoration;

trait UndocumentedBell {

    public $undocumentedBell;
}
